function sub()
{
	var a=20;
	var b=10;
	alert("sum="+(a-b));
	console.log("sum="+(a-b));
}
function mul()
{
	var a=20;
	var b=10;
	alert("mul="+(a*b));
	console.log("mul="+(a*b));
}